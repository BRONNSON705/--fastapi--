Проект FastAPI - платформа для обзоров игр

# GameReviews Platform

![Python](https://img.shields.io/badge/Python-3.11%2B-blue)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104%2B-green)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15%2B-blue)
![Render](https://img.shields.io/badge/Render.com-Cloud-purple)

Полнофункциональная веб-платформа для публикации и чтения обзоров видеоигр.

## 📋 О проекте

Проект разработан в рамках учебного задания для демонстрации навыков FullStack разработки на Python с использованием FastAPI.

### Основные возможности:
- 📝 Публикация обзоров на видеоигры
- ⭐ Система оценок (1-10 баллов)
- 👥 Регистрация и аутентификация пользователей
- 💬 Комментарии к обзорам
- 🔍 Поиск игр по названию, жанру, разработчику
- 📊 Статистика по играм

## 🏗️ Архитектура

### База данных (PostgreSQL)