# app/database.py
# Временный заглушка для демо
print("Database module loaded (demo mode)")
